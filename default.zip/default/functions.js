import {registerWidgetArea} from '../../includes/widgets'

const functions = function(){		
	registerWidgetArea("Sidebar");
	registerWidgetArea("Single");
	registerWidgetArea("Footer");
}

export default functions
